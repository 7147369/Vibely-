If android folder not fully generated, run 'flutter create .' or open in Android Studio to generate platform folders.
