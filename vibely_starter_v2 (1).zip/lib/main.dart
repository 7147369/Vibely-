import 'package:flutter/material.dart';

void main() {
  runApp(VibelyApp());
}

class VibelyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vibely',
      theme: ThemeData(
        primaryColor: Color(0xFF1DB954),
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 1,
        ),
      ),
      home: MainTabs(),
    );
  }
}

class MainTabs extends StatefulWidget {
  @override
  _MainTabsState createState() => _MainTabsState();
}

class _MainTabsState extends State<MainTabs> {
  int _currentIndex = 0;
  final _pages = [
    HomeScreen(),
    ExploreScreen(),
    CreateScreen(),
    ActivityScreen(),
    MessagesScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: Color(0xFF1DB954),
        unselectedItemColor: Colors.grey,
        onTap: (i) => setState(() => _currentIndex = i),
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Search'),
          BottomNavigationBarItem(icon: Icon(Icons.add_box), label: 'Create'),
          BottomNavigationBarItem(icon: Icon(Icons.favorite_border), label: 'Activity'),
          BottomNavigationBarItem(icon: Icon(Icons.message), label: 'Messages'),
        ],
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Vibely', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF1DB954)))),
      body: ListView.builder(
        itemCount: 6,
        itemBuilder: (context, i) {
          return Card(
            margin: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListTile(
                  leading: CircleAvatar(child: Icon(Icons.person)),
                  title: Text('username_$i'),
                  subtitle: Text('Location'),
                  trailing: Icon(Icons.more_vert),
                ),
                Container(
                  height: 250,
                  color: Colors.grey[300],
                  child: Center(child: Text('Post media placeholder')),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: Row(
                    children: [
                      Icon(Icons.favorite_border),
                      SizedBox(width: 12),
                      Icon(Icons.comment),
                      SizedBox(width: 12),
                      Icon(Icons.send),
                      Spacer(),
                      Icon(Icons.bookmark_border),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 0),
                  child: Text('username_$i  This is a sample caption for the post. #hashtag', style: TextStyle(fontWeight: FontWeight.w500)),
                ),
                SizedBox(height: 12),
              ],
            ),
          );
        },
      ),
    );
  }
}

class ExploreScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Explore')),
      body: GridView.builder(
        padding: EdgeInsets.all(8),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 8, crossAxisSpacing: 8),
        itemCount: 30,
        itemBuilder: (context, i) => Container(color: Colors.grey[300], child: Center(child: Text('Img'))),
      ),
    );
  }
}

class CreateScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Create')),
      body: Center(child: Text('Upload / Camera flow placeholder')),
    );
  }
}

class ActivityScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Activity')),
      body: Center(child: Text('Notifications placeholder')),
    );
  }
}

class MessagesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Messages')),
      body: ListView.builder(
        itemCount: 10,
        itemBuilder: (context, i) => ListTile(
          leading: CircleAvatar(child: Icon(Icons.person)),
          title: Text('user_$i'),
          subtitle: Text('Last message preview...'),
          trailing: Text('12:0${i}'),
        ),
      ),
    );
  }
}
